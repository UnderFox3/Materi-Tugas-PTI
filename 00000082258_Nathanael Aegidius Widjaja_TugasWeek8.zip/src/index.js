import React from "react";
import ReactDOM from "react-dom";

const firstName = "Nathanael";
const middleName = "Aegidius";
const lastName = "Widjaja";

function numberGenerator() {
  var a = Math.floor(Math.random() * 255);
  var b = Math.floor(Math.random() * 255);
  var c = Math.floor(Math.random() * 255);
  return `rgb(${a},${b},${c})`;
}

const styleColor1 = {
  color: numberGenerator(),
};

const styleColor2 = {
  color: numberGenerator(),
};

const styleColor3 = {
  color: numberGenerator(),
};

const styleColor4 = {
  color: numberGenerator(),
};

const styleColor5 = {
  color: numberGenerator(),
};

const styleColor6 = {
  color: numberGenerator(),
};

ReactDOM.render(
  <div>
    <h1 style={styleColor1}>Hello World</h1>
    <p style={styleColor2}>
      My name is {firstName} {middleName} {lastName}
    </p>
    <p style={styleColor3}>I am a handsome human being</p>
    <p style={styleColor4}>I love to learn JavaScript</p>
    <p style={styleColor5}>I am a high quality student</p>
    <p style={styleColor6}>I am going to be a super star</p>
  </div>,
  document.getElementById("root")
);
